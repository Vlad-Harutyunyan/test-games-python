import pygame
from time import sleep
pygame.init()     
   
screen = pygame.display.set_mode((800,600))
#title
pygame.display.set_caption('vlad game') 

clock = pygame.time.Clock()
  
#player
playerImg = [pygame.image.load("character/idle/Idle__000.png"),pygame.image.load("character/idle/Idle__001.png"),pygame.image.load("character/idle/Idle__002.png"),pygame.image.load("character/idle/Idle__003.png"),pygame.image.load("character/idle/Idle__004.png"),pygame.image.load("character/idle/Idle__005.png"),pygame.image.load("character/idle/Idle__006.png"),pygame.image.load("character/idle/Idle__007.png"),pygame.image.load("character/idle/Idle__008.png"),pygame.image.load("character/idle/Idle__009.png")]
playerRun = [pygame.image.load("character/run/Run__000.png"),pygame.image.load("character/run/Run__001.png"),pygame.image.load("character/run/Run__002.png"),pygame.image.load("character/run/Run__003.png"),pygame.image.load("character/run/Run__004.png"),pygame.image.load("character/run/Run__005.png"),pygame.image.load("character/run/Run__006.png"),pygame.image.load("character/run/Run__007.png"),pygame.image.load("character/run/Run__008.png"),pygame.image.load("character/run/Run__009.png")]
playerJump = [pygame.image.load("character/jump/Jump__000.png"),pygame.image.load("character/jump/Jump__001.png"),pygame.image.load("character/jump/Jump__002.png"),pygame.image.load("character/jump/Jump__003.png"),pygame.image.load("character/jump/Jump__004.png"),pygame.image.load("character/jump/Jump__005.png"),pygame.image.load("character/jump/Jump__006.png"),pygame.image.load("character/jump/Jump__007.png"),pygame.image.load("character/jump/Jump__008.png"),pygame.image.load("character/jump/Jump__009.png")]
playerAttack = [pygame.image.load("character/attack/Attack__000.png"),pygame.image.load("character/attack/Attack__001.png"),pygame.image.load("character/attack/Attack__002.png"),pygame.image.load("character/attack/Attack__003.png"),pygame.image.load("character/attack/Attack__004.png"),pygame.image.load("character/attack/Attack__005.png"),pygame.image.load("character/attack/Attack__006.png"),pygame.image.load("character/attack/Attack__007.png"),pygame.image.load("character/attack/Attack__008.png"),pygame.image.load("character/attack/Attack__009.png")]
run_count = 0
run_check = False

stand_count = 0

jump_count = 0
jump_check = False
#cloud
attack_count = 0
attack_check = False
cloud1 =  pygame.image.load('cloud-4.png')  
cloud2 =  pygame.image.load('cloud-5.png')
cloud3 =  pygame.image.load('cloud-5.png')  

#images
gr = pygame.image.load('hr3.png')
gr2 = pygame.image.load('hr3.png')
gr3 = pygame.image.load('bg1.jpg')
gr4 = pygame.image.load('hr2.png')
gr5 = pygame.image.load('hr2.png') 

playerX = 355 
playerY = 460  

cloud1_cordX = 10
cloud1_cordY = 10

cloud2_cordX = 200
cloud2_cordY = 10

cloud3_cordX = 600
cloud3_cordY = 10

bg_cordX = 0

bg2_cordX = 0
bg3_cordX = 300

def draw():
    screen.blit(gr3,(bg_cordX,0))    
    screen.blit(cloud1,(cloud1_cordX,cloud1_cordY))
    screen.blit(cloud2,(cloud2_cordX,cloud2_cordY))
    screen.blit(cloud3,(cloud3_cordX,cloud3_cordY)) 
    
    screen.blit(gr,(0,345))
    screen.blit(gr2,(300,345))  
    player(playerX,playerY) 
    screen.blit(gr4,(bg2_cordX,343)) 
    screen.blit(gr4,(bg3_cordX,343))

def player(x,y): 
    if run_check : 
        temp = playerRun[run_count]
        temp = pygame.transform.scale(temp, (110, 130))

        screen.blit(temp,(x,y))
    elif jump_check :
        temp = playerJump[jump_count] 
        temp = pygame.transform.scale(temp, (100, 130))
 
        screen.blit(temp,(x,y))
    elif attack_check :
        temp = playerAttack[attack_count] 
        temp = pygame.transform.scale(temp, (120, 130))
    
        screen.blit(temp,(x,y))    
    else : 
        temp = playerImg[stand_count]
        temp = pygame.transform.scale(temp, (70, 130))

        screen.blit(temp,(x,y)) 

def jump (): 
    playerY -= 10

#Game loop  
run = True
while run:
    clock.tick(23)
    stand_count += 1
    cloud2_cordX -= 0.09
    cloud1_cordX -= 0.05
    cloud3_cordX -= 0.09
    for event in pygame.event.get():
        if event.type == pygame.QUIT: 
            run = False 
    screen.fill((0,20,30))
    
    #press 
    pressed = pygame.key.get_pressed() 
    if pressed[pygame.K_RIGHT] or pressed[pygame.K_LEFT]:
        
        run_count += 1 
        run_check = True 
    else :  
        run_check = False

    if pressed[pygame.K_q]:
        
        attack_check = True 
        attack_count+=1
    else : 
        attack_check = False 

    #jump 
    if pressed[pygame.K_SPACE]: 
        jump_check = True
        clock.tick(103)
        jump_count += 1
        if playerY >= 460 : 
            
            playerY -= 100
    else :
        jump_check = False


    if playerY < 460 :
        playerY += 10 
    
    if jump_count <=0:
        jump_count = 9
    if jump_count >=9:
        jump_count = 0
    #keydown

    if event.type == pygame.KEYDOWN:
       

        if event.key == pygame.K_LEFT:
            playerX -= 2
        temp = run_count+1
        
        
        if event.key == pygame.K_RIGHT:
            
            if playerX < 355 :
                playerX += 2
            bg_cordX -= 2   
            bg2_cordX -= 2
            bg3_cordX -= 2

            
    if attack_count >= 9 :
        attack_count = 0 
    if bg2_cordX == 160 or bg3_cordX == 140 :
        bg2_cordX = 300
        bg3_cordX = 0
    if playerX >= 698 :
        playerX = 690
    if playerX <= 0:
        playerX = 0
    if playerY <= 0:
        playerY = 0
    if playerY >= 600:
        playerY = 600
    if cloud2_cordX <= 0:
        cloud2_cordX = 750
    if cloud1_cordX <= 0:
        cloud1_cordX = 750
    if cloud3_cordX <= 0:
        cloud3_cordX = 750
    if bg_cordX <= -1010 :
        bg_cordX = -100
    if stand_count >= 9 :
        stand_count = 0 
    if run_count >= 9 :
        run_count = 0
    draw()   
    
    pygame.display.update()